#!/bin/sh
BASE=$(cd $(dirname $0)/.. && pwd)
export LD_LIBRARY_PATH=$BASE/lib
export OTAI_SIM_DATA_PATH=$BASE/otai_sim_data
cd $BASE

mkdir -p $BASE/logs
cp $BASE/swss/*.lua /usr/share/swss

printf 'OTAI_LINECARD_LOCATION=1\nOTAI_VS_LINECARD_TYPE=OTAI_VS_LINECARD_TYPE_OTN\n' > /tmp/otai_test.profile
# 守护进程输出必须重定向到日志文件：不得继承调用方的 stdout 管道——
# run_command 用 Popen(stdout=PIPE)+communicate() 等 EOF，常驻子进程持有管道写端
# 会永久阻塞（供应流程死锁根因，2026-10-22）
# 日志落地：LOGGER 表(db4)，供应流程 flush 后自动重建
R=/var/run/redis/redis.sock
$BASE/bin/redis-cli -s $R -n 4 hset "LOGGER|syncd"        LOGOUTPUT STDERR >/dev/null 2>&1
$BASE/bin/redis-cli -s $R -n 4 hset "LOGGER|syncd"        LOGLEVEL  NOTICE >/dev/null 2>&1
$BASE/bin/redis-cli -s $R -n 4 hset "LOGGER|orchagent"    LOGOUTPUT STDERR >/dev/null 2>&1
$BASE/bin/redis-cli -s $R -n 4 hset "LOGGER|orchagent"    LOGLEVEL  NOTICE >/dev/null 2>&1
$BASE/bin/redis-cli -s $R -n 4 hset "LOGGER|linecardmgrd" LOGOUTPUT STDERR >/dev/null 2>&1
$BASE/bin/redis-cli -s $R -n 4 hset "LOGGER|configsyncd"  LOGOUTPUT STDERR >/dev/null 2>&1

./bin/syncd -p /tmp/otai_test.profile >> $BASE/logs/syncd.log 2>&1 &
sleep 5

./bin/orchagent -b 8192 >> $BASE/logs/orchagent.log 2>&1 &
sleep 2
./bin/linecardmgrd >> $BASE/logs/linecardmgrd.log 2>&1 &
./bin/configsyncd >> $BASE/logs/configsyncd.log 2>&1 &
echo "=== daemons started"
