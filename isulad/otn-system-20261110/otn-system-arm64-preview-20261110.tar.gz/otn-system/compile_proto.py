from pathlib import Path
import subprocess,sys,grpc_tools
r=Path('/system');p=r/'proto/gnmi.proto'
p.write_text(p.read_text().replace('github.com/openconfig/gnmi/proto/gnmi_ext/gnmi_ext.proto','gnmi_ext/gnmi_ext.proto'))
out=r/'generated';out.mkdir(exist_ok=True)
subprocess.run([sys.executable,'-m','grpc_tools.protoc','-I'+str(r/'proto'),'-I'+str(Path(grpc_tools.__file__).parent/'_proto'),'--python_out='+str(out),'--grpc_python_out='+str(out),str(p),str(r/'proto/gnmi_ext/gnmi_ext.proto')],check=True)
