"""Reproducible file manifest; never package credentials, fixtures modified by tests or sockets."""
from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;out=r/'dist-final';out.mkdir(exist_ok=True)
stage=out/'otn-system'
if stage.exists():raise SystemExit('dist/otn-system already exists; choose a clean staging directory')
stage.mkdir()
ignore=shutil.ignore_patterns('__pycache__','*.pyc','state','runs','redis','.git')
shutil.copytree(r.parent/'otn-linklab/package/otn-linklab',stage/'core',ignore=ignore)
shutil.copyfile(r/'core_runtime.py',stage/'core/runtime.py')
for name in ['python','deps','native-pmon','generated','proto']:
 shutil.copytree(r/name,stage/name,ignore=ignore)
for p in r.iterdir():
 if p.is_file() and (p.suffix in ('.py','.json','.txt','.md','.go') or p.name in ('system.sh','north-gateway-arm64')):
  shutil.copyfile(p,stage/p.name)
# Retain upstream notices alongside Python dependency dist-info licenses.
licenses=stage/'licenses';licenses.mkdir()
repo=r.parent/'sonic-buildimage-isulad/src'
for name in ['sonic-platform-daemons','sonic-platform-common','sonic-py-common']:
 for p in (repo/name).iterdir():
  if p.is_file() and p.name.upper().startswith(('LICENSE','COPYING','NOTICE')):shutil.copyfile(p,licenses/(name+'-'+p.name))
(stage/'north-gateway-arm64').chmod(0o755)
files={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'SHA256-MANIFEST.json').write_text(json.dumps(files,indent=2))
archive=out/'otn-system-arm64-preview-20261110.tar.gz'
with tarfile.open(archive,'w:gz') as f:f.add(stage,arcname='otn-system')
(out/(archive.name+'.sha256')).write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
size=sum(p.stat().st_size for p in stage.rglob('*') if p.is_file())
report={'archive_bytes':archive.stat().st_size,'unpacked_regular_file_bytes':size,'files':len(files),'status':'integration preview, not complete SONiC-OTN distribution'}
(out/'build-size.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
