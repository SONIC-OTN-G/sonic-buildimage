import argparse,json
import management as m
p=argparse.ArgumentParser();p.add_argument('command',choices=['show','set','save']);p.add_argument('args',nargs='*');a=p.parse_args()
if a.command=='show' and len(a.args)==1:result=m.read(a.args[0])
elif a.command=='set' and len(a.args)==4:result=m.write(*a.args)
elif a.command=='save' and not a.args:result=m.save()
else:p.error('show RESOURCE | set TABLE KEY FIELD VALUE | save')
print(json.dumps(result,indent=2))
