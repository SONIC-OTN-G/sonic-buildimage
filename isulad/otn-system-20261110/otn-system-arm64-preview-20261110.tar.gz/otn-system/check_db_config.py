import json,time
from pathlib import Path
p=Path('/var/run/redis/sonic-db/database_config.json')
for _ in range(100):
 if p.exists():break
 time.sleep(.1)
d=json.loads(p.read_text())['DATABASES']
assert d['CHASSIS_STATE_DB']['id']==13 and d['CHASSIS_APP_DB']['id']==12
print('PASS chassis databases configured at startup')
