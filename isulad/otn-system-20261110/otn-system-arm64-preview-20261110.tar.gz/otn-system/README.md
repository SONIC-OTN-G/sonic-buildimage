# SONiC-OTN pmon / 北向增量联调预览版（2026-11-10）

本目录是已经实测的增量实现，**不是已经补齐全部功能的 SONiC-OTN 发行版**。
原来的 0.53 MiB 联调包没有 pmon；其中 PM 指光层性能监测，不能替代平台监控。
本版复用已有三个 ARM64 镜像，启动 database、otss、syncd、pmon、north 五个独立容器。
pmon 和 north 复用 database 镜像中的 Python/Redis/swsscommon，依赖和代码只读挂载，不重新构建完整发行镜像。

## 已实现与验证

| 功能 | 实现和证据 | 边界 |
|---|---|---|
| 平台电源 | 原生 psud；电源拔出/插入状态通过 | 电压、电流、功率和在位来自虚拟驱动 |
| 风扇、温度 | 原生 thermalctld；温度上报、78 C 时全速、35 C 恢复通过 | 平台自定义固定 70/65 C 温控策略；执行器即时模拟 |
| EEPROM | 原生 syseepromd；ONIE TLV/CRC 与 STATE_DB 上报 | 内容为虚拟设备标识 |
| 机框模块 | 原生 chassisd；Empty/Online 转换通过 | 不等于 OTN 对象随插拔销毁、重建 |
| 配置下发 | CLI、REST、gNMI、NETCONF 的写入取得原生回执和 OTAI GET 读回 | 单一已有对象属性；非完整事务/YANG 管理 |
| 光层 PM | 真实 syncd collector 写 COUNTERS_DB；12.25/17.75 变化通过 | getStats 数据源虚拟；未在本轮等满 15 分钟验证历史窗口 |
| 光层告警 | 真实 OTAI callback/syncd；产生、去重、清除、历史通过 | 告警源注入；与 pmon syslog 告警不是同一条实现 |
| 北向读取 | REST TLS、gNMI Get/Subscribe ONCE、NETCONF SSH get、SNMPv3 authPriv 通过 | 自定义联调模型；没有宣称 OpenConfig 全模型兼容 |
| 跨命名空间 | ARM64 Go 网关 + Unix socket；四协议端到端通过 | 本地隔离 Docker/QEMU 测试；未在目标设备运行 |

原生 psud、thermalctld、syseepromd、chassisd 脚本不修改。
共享 sonic_py_common 的 db_connect 改用 Unix socket。新 database 入口每次启动写入 CHASSIS_APP_DB=12 和 CHASSIS_STATE_DB=13，修复重启后定义丢失。
SYSTEM_SERVICE 表只说明监督进程是否存活，不代表每个内部线程、每项数据都新鲜。

## 数据与接口

平台硬件边界是 `python/sonic_platform/driver.py` 中 HardwareDriver：
`inventory()` 返回稳定设备 ID；`read(kind,id)` 返回有类型字段，I/O 失败抛 OSError；
`write(kind,id,field,value)` 只在接受执行后返回 True。
当前 VirtualDriver 读写 state/platform.json。未来用 `OTN_PLATFORM_DRIVER=vendor_driver:Driver` 替换，供应商模块须继承 HardwareDriver。
驱动不写 Redis；平台 API → 原生 pmon 守护进程 → STATE_DB → 北向读取。
单独的内核/I2C/EEPROM/风扇控制适配代码应放在驱动实现，不放入北向接口。

配置：CLI/REST/gNMI/NETCONF → management.py → CONFIG_DB + operation-id → configsyncd → APPL_DB → orchagent → libotairedis → ASIC_DB → 原生 syncd → 虚拟 libotaivs。
返回使用 OT_OPERATION_RESULT；测试额外调用 OTAI GET，避免只确认“Redis 写成功”。
超时返回结果未知，不当作成功；失败的期望值可能仍在 CONFIG_DB。重新成功下发该属性后才能清除北向未确认标记，save 会阻止持久化仍有标记的配置。
Redis 未开启持久化；只有显式 `cli save` 的 startup.json 在完整重建联调栈时重放；告警历史不会跨数据库重启保存。

北向协议均为本版适配器，并非重新编译的完整 sonic-mgmt-framework/sonic-gnmi/snmpd：

- CLI：`show config|platform|performance|alarms|history|objects|services|operations|capabilities`，`set TABLE KEY FIELD VALUE`，`save`。
- REST：HTTPS 8443，Bearer 认证；GET `/v1/{resource}`；POST `/v1/config` JSON `{table,key,field,value}`；POST `/v1/save` `{}`。不是 RESTCONF。
- gNMI：TLS 9339、Bearer metadata；模型 sonic-otn-system；JSON Get、单项 Set、ONCE/STREAM 订阅。路径 `/config/object[table=AMPLIFIER][name=AMPLIFIER-1-1-1]/field[name=target-gain]`；读取路径如 `/platform`。本轮只验证 ONCE，STREAM 尚未验收。不支持批量原子事务、删除、替换和完整 OpenConfig。
- NETCONF：SSH 8300、NETCONF 1.0 framing、自定义 XML 模型；get/get-config、单属性 edit-config、close-session；不支持 candidate/commit/rollback、完整 YANG 校验及完整 NETCONF 基础操作集，因此是协议联调适配器。
- SNMP：UDP 1161、SNMPv3 SHA256/AES authPriv，只读 system 标量和温度 ENTITY/ENTITY-SENSOR 子集；不支持 SNMP SET、完整 MIB、trap/inform。温度状态尚无可靠过期判定。

证书、SSH host key、口令和 token 在首次启动生成，保存在 state/security；不会进入发行包。使用前校对设备时间，信任/拷贝本机生成的证书与主机公钥；不要关闭证书验证。

## 上传与安装

前提：已有 iSulad 离线引擎正常运行，三个镜像 tag 与 system.sh 一致。
本包用于独立联调，不接管设备厂商服务；全部容器 network none，不挂载 /dev 或特权模式。

1. 从工作站上传 `otn-system-arm64-preview-20261110.tar.gz` 和对应 sha256 文件到设备临时目录。
2. 使用设备 `sha256sum -c`（或离线引擎 busybox sha256sum）核对摘要。
3. 解压到引擎 `ENGINE/evidence/`，得到 `ENGINE/evidence/otn-system/system.sh`。ENGINE 是你现有部署说明中包含 control.sh、isula、bin/busybox 的目录，不是固定的 /opt 路径。
4. `sh ENGINE/evidence/otn-system/system.sh start`。如中途失败，检查日志后先执行 stop，再重新 start；不要只重启 database，其他进程的 Redis 连接和初始化状态需要一起重建。
5. `sh ENGINE/evidence/otn-system/system.sh test`。此命令会注入虚拟电源/板卡插拔与温度变化，测试后恢复输入值；温度周期较慢，整个测试预留约 3 分钟。
6. `sh ENGINE/evidence/otn-system/system.sh cli show platform`；例如配置 `cli set AMPLIFIER AMPLIFIER-1-1-1 target-gain 13`。
7. `sh ENGINE/evidence/otn-system/system.sh stop` 仅停止并删除带本版标记的五个测试容器；保留 state、startup.json 和日志，便于复核。原来的三个容器不被改名或替换。

外部管理入口单独启用：设备宿主执行 `north-gateway-arm64 -state /绝对路径/ENGINE/evidence/otn-system/state`，以前台方式运行；只监听宿主 127.0.0.1 的 TCP 8443/9339/8300 和 UDP 1161。
另一终端可用 SSH 本地转发访问三个 TCP 端口，例如 `ssh -N -L 8443:127.0.0.1:8443 -L 9339:127.0.0.1:9339 -L 8300:127.0.0.1:8300 用户@设备`。
SNMP UDP 不通过普通 SSH -L 转发；可以在设备本地访问，外部网管连接需另行配置受控网络入口。
不自动添加开机服务或防火墙规则。Unix socket 路径受 Linux 长度限制，安装路径应尽量短。
现有 iSulad 是否完整支持这些 run/exec 参数需目标设备验收；本轮只验证了 Docker 对应行为和脚本 shell 语法。

## 距离“完整 SONiC-OTN”仍需完成

1. 原生 linecardmgr/板卡生命周期：将 pmon 在位变化与下电、对象删除、插回恢复、依赖顺序、失败回滚贯通。目前启动仍采用 v1 synthetic bootstrap，不应把拔卡时继续存在的 OTN 对象视为正确生命周期。
2. 按实际板型补齐所有 OTAI 对象与配置模型；当前模板只有 LINECARD、AMPLIFIER、ATTENUATOR、PORT，共 33 个非 LINECARD 对象。不是所有 OTN 交叉连接、保护、OTDR、OCM 等能力的验收。
3. 根据平台需要接入 xcvrd/SFP DOM、watchdog、PCIe、存储健康、LED 统一策略等。复制的 API 基类不等于这些功能已实现。
4. 引入/适配原生北向管理栈和正式 YANG/OpenConfig/MIB：模型校验、权限、完整事务、告警订阅/推送、SNMP traps，以及对接实际网管的互通测试。
5. 平台告警当前通过原生 syslog 和 STATE_DB 暴露；还需统一活动告警、确认/抑制/清除、历史保留和北向推送。数据采集失败/过期状态也需统一，不能沿用旧健康值。
6. 增加有界历史持久化、崩溃恢复、升级回滚、运行时自启动和完整故障恢复验收。当前监督器 fail-fast，不会自动重启子进程。

这些是软件缺口，不能因为“硬件先虚拟化”而省略。当前预览版可验证已列出的链路，不能据此宣布目标设备已经具备完整 SONiC-OTN 功能。

## 空间

以 dist/build-size.json 的实测压缩/展开大小为准。新包包含 Python 依赖、原生平台脚本和静态网关，不再是原来约 0.53 MiB 的三个二进制差分。
复用现有镜像，不重复传镜像/编译缓存；下载的 wheels 和测试 state/security 均不打包。
4 GiB 可作为增量部署预算：先预留 0.5 GiB 给包与解压临时文件，至少 0.5 GiB 给容器可写层和日志，其余用于后续北向原生依赖与有界历史。
这是磁盘预算，不是 RAM 需求估算；Redis maxmemory=256 MiB 限制内存，不能当作磁盘占用。
完整发行版/构建目录超过 20 GB 与本增量运行包不是同一统计口径；未逐目录复核前不能把那 20 GB 全归因于运行程序。
