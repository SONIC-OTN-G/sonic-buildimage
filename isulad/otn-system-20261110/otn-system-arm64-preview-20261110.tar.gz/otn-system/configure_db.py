"""Compatibility repair for a running v1 lab; new installs use core_runtime.py."""
import json
from pathlib import Path
p=Path('/var/run/redis/sonic-db/database_config.json')
d=json.loads(p.read_text())
d['DATABASES'].update({n:{'id':i,'separator':'|','instance':'redis'} for n,i in [('CHASSIS_APP_DB',12),('CHASSIS_STATE_DB',13)]})
p.write_text(json.dumps(d))
