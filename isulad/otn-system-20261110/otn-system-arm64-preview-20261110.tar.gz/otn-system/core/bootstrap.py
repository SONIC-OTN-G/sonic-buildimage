"""Single synthetic platform/boot adapter for a private test Redis only."""
import json,time
from pathlib import Path
import redis
from swsscommon import swsscommon as s
r=redis.Redis(unix_socket_path='/var/run/redis/redis.sock',decode_responses=True)
if r.dbsize(): raise RuntimeError('APPL_DB must be empty; use a new isolated lab instance')
cfg=s.DBConnector('CONFIG_DB',0);app=s.DBConnector('APPL_DB',0);state=s.DBConnector('STATE_DB',0)
startup=Path('/lab-state/startup.json')
data=json.loads((startup if startup.exists() else Path('/lab/config/config_db.json')).read_text())
for table,rows in data.items():
 for key,fields in rows.items():
  s.Table(cfg,table).set(key,s.FieldValuePairs([(k,str(v).lower() if isinstance(v,bool) else str(v)) for k,v in fields.items()]))
s.Table(state,'LINECARD').set('LINECARD-1-1',s.FieldValuePairs([('oper-status','ACTIVE'),('power-admin-state','POWER_ENABLED')]))
s.ProducerStateTable(app,'APP_LINECARD').set('LINECARD-1-1',s.FieldValuePairs(list(data['LINECARD']['LINECARD-1-1'].items())))
print('BOOTSTRAP_PASS synthetic platform slot=1; CONFIG_DB loaded; APP_LINECARD submitted')
