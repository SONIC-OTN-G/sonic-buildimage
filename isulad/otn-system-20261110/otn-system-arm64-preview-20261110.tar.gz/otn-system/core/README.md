# ARM64 SONiC-OTN 三容器联调包

日期：2026-11-09。目标是在厂商 ARM64 Linux 5.10 和已经验证的离线 iSulad 环境中，验证配置下发、性能监测和设备告警的软件闭环。此包不访问真实设备，不要求更换内核或系统。

## 实现边界

- database 运行真实 Redis。
- OTSS 运行真实 configsyncd、orchagent，复用此前完整仿真树中配置回执、GET 回读、对象隔离等修复。
- syncd 使用已有 ARM64 原生程序，动态加载本包新编译的 libotaivs；对象属性保存在虚拟 OTAI 内存中。
- PM 测试修改虚拟 OTAI 的输入文件，由 syncd 原生采集器调用 getStats，写入 COUNTERS_DB。
- 告警测试通过虚拟 OTAI 回调进入 syncd 原生通知处理，检查 STATE_DB 当前告警及历史库。该分支历史库真实名称是 GB_COUNTERS_DB（DB 10）。
- 启动适配器模拟单槽位在位/上电状态，并提交 APP_LINECARD。这里只模拟平台状态，不声称完成真实热插拔。
- 不通过脚本直接写入操作结果、性能或告警表来制造通过结果。

配置、PM、告警并不是同一条串行通道：配置经过 CONFIG_DB、configsyncd、APPL_DB、orchagent、otairedis、syncd 和虚拟 OTAI；PM/告警由虚拟 OTAI 经 syncd 写回数据库，管理端查询结果。OTSS 负责建立对象及采集配置，并不要求每条 PM/告警都再次经 OTSS 转发。

第一版使用 E110C 模板中的放大器、衰减器和端口对象。用一个槽位证明三项机制，再扩展其他板型和对象。它不是全部 SONiC-OTN 字段、全部北向协议或真实硬件功能的认证。

## 交付结构

`otn-linklab-arm64-20261109.tar.gz` 解包得到 `otn-linklab/`：

- `bin/`：ARM64 orchagent、configsyncd、libotaivs。
- `config/`：最小板卡配置与原生 flexcounter 配置。
- `sim-data/`：虚拟 OTAI 对象初始数据。
- `lab.sh`：启动、停止和验收入口。
- `runtime.py`：进程管理及滚动日志，子进程异常时容器退出。
- `bootstrap.py`：独立 Redis 的启动配置与模拟平台初始化。
- `check.py`：配置、PM、告警验收与查询、保存。
- `SHA256SUMS`、`manifest.json`：文件校验和版本范围。

运行后生成 `state/`（配置、输入、报告、日志）和 `runs/`（每次启动独立 Redis socket）。停止不会删除这些证据。

## 上传和安装

前提：沿用已经成功部署的 `isulad-offline-arm64/` 目录以及三个现有镜像标签：

```
sonic-database-standalone:arm64-20261022
sonic-otss-standalone:arm64-20261023
sonic-syncd-standalone:arm64-20261023
```

1. 从电脑上传本次 tar.gz 和配套外部校验文件到设备已有引擎目录的 `inbox/`。下面用原文档路径举例，设备地址按实际替换：

```powershell
scp .\otn-linklab-arm64-20261109.tar.gz root@设备地址:/ofs1/isulad-fix-20261106/isulad-offline-arm64/inbox/
scp .\otn-linklab-arm64-20261109.sha256 root@设备地址:/ofs1/isulad-fix-20261106/isulad-offline-arm64/inbox/
```

2. 登录设备，校验并解包。安装目录必须是引擎下的 `evidence/otn-linklab`，因为该目录已经映射进入引擎 chroot。

```sh
cd /ofs1/isulad-fix-20261106/isulad-offline-arm64
(cd inbox && ../bin/busybox sha256sum -c otn-linklab-arm64-20261109.sha256)
# 首次安装；如果已有 evidence/otn-linklab，先停止并备份旧目录，不覆盖运行中的文件。
test ! -e evidence/otn-linklab || exit 1
./bin/busybox tar -xzf inbox/otn-linklab-arm64-20261109.tar.gz -C evidence
(cd evidence/otn-linklab && ../../bin/busybox sha256sum -c SHA256SUMS)
sh control.sh start
sh isula images
sh evidence/otn-linklab/lab.sh start
```

若引擎已经启动，按原控制脚本返回状态处理，不启动第二套引擎。包内二进制必须位于允许执行的分区。无需宿主机安装 Python，Python 和依赖由现有镜像提供。

3. 执行三项功能验收：

```sh
sh evidence/otn-linklab/lab.sh test
# 也可以逐项执行
sh evidence/otn-linklab/lab.sh config
sh evidence/otn-linklab/lab.sh pm
sh evidence/otn-linklab/lab.sh alarm
sh evidence/otn-linklab/lab.sh show
```

每项输出 JSON，只有全部通过才返回 0。失败保持日志和容器供诊断，不把超时当作成功。`state/latest-results.json` 保存最近一次命令的报告，运行下一次测试前可按需复制留档。

也可以手工演示。set 的读回来自原生 OTAI GET；注入命令只确认输入已提交，最终效果通过 show/数据库查询或对应验收脚本确认：

```sh
sh evidence/otn-linklab/lab.sh get AMPLIFIER-1-1-1 target-gain
sh evidence/otn-linklab/lab.sh set AMPLIFIER-1-1-1 target-gain 13
sh evidence/otn-linklab/lab.sh inject-pm 17.75
sh evidence/otn-linklab/lab.sh inject-alarm on
sh evidence/otn-linklab/lab.sh show
sh evidence/otn-linklab/lab.sh inject-alarm off
```

4. 停止、保存与重新启动：

```sh
sh evidence/otn-linklab/lab.sh save
sh evidence/otn-linklab/lab.sh stop
sh evidence/otn-linklab/lab.sh start
sh evidence/otn-linklab/lab.sh test
```

`save` 将当前模板所含配置原子写入 `state/startup.json`，再次启动优先加载它。Redis 是可重建运行缓存，未启用 AOF/RDB；历史 PM/告警不会跨整套实验重启保留。本轮目标不包含生产级历史数据持久化或掉电恢复保证。停启是整套实验冷恢复，不能等同于任意单进程 warm restart。

## 验收标准

| 项目 | 检查 |
|---|---|
| 初始化 | 所有模板对象达到 APPLIED，原生 GET 可响应 |
| 配置 | 唯一 operation-id，实时响应和可查询结果一致，GET 回读为目标值，另一个对象不受影响，最后恢复原值 |
| 非法配置 | 非法 amp-mode 被拒绝，虚拟 OTAI 旧值保持，恢复合法配置 |
| PM | 从后端注入 12.25、17.75 两个不同增益读数，原生采集器依次发布对应 instant 值 |
| 告警 | 注入温度告警、确认当前告警、重复注入不重复建表、清除后进入历史且有清除时间 |

PM 当前 15 分钟/24 小时窗口由原生代码维护；短测试只验证采集和当前窗口，不能声称完成真实等待 15 分钟/24 小时的全周期历史验收。光功率等输入均是合成数据。

需要验证 15 分钟历史时，保持三个容器运行并执行 `sh evidence/otn-linklab/lab.sh pm-history`。它最多等待 960 秒，核对新生成历史记录的窗口时间、有效性、最小/最大/平均/瞬时值，不修改系统时钟。首次不足一个完整周期的窗口允许标记 incomplete。此长测试不包含在默认 test 中；24 小时历史另需连续运行跨越日窗口再验收。

## 空间和隔离

复用现有镜像；本包只挂载少量新程序，不再复制整个系统盘，不需要安装 20+ GB 发行版。按约 4 GB 规划，优先保留运行组件，不上传构建环境和 `.o` 文件。最终包大小见校验/验收记录。

三个容器均使用 `--network none` 和独立 Redis socket，不绑定宿主设备、不请求 privileged。数据位于引擎已允许的 evidence 映射中。旧的独立探测容器与本实验使用不同名称、不同数据库，不自动删除或修改旧容器。

每个角色日志限制为当前 2 MiB 加两份备份。Redis 配置 256 MiB 上限和 noeviction；达到上限会报错而非静默淘汰配置。磁盘日志有界不等于整个设备内存需求仅 256 MiB。

## 排障

```sh
sh evidence/otn-linklab/lab.sh status
./bin/busybox tail -n 100 evidence/otn-linklab/state/otss.log
./bin/busybox tail -n 100 evidence/otn-linklab/state/syncd.log
./bin/busybox tail -n 100 evidence/otn-linklab/state/database.log
sh isula logs linklab-otss
sh isula logs linklab-syncd
```

`start` 遇到已有实验容器会拒绝覆盖。先检查失败原因，再 `stop`、`start`；不要执行全局 prune 或 FLUSHALL。测试串行加锁，避免多份脚本互相改输入或覆盖结果。

## 本轮验证记录

2026-11-09 已在开发机 WSL/Docker 中通过 QEMU 用户态运行实际 ARM64 二进制，完成两轮三容器验收：33 个模板对象 APPLIED；配置回执与 GET 回读一致、另一对象保持不变、非法枚举拒绝；PM instant 依次变为 12.25 和 17.75；温度告警产生、重复抑制、清除及历史入库通过。将增益保存为 12.5 后停止并重建全部三个容器，重新读回 12.5，第二轮验收再次通过。另检查 syncd 的进程映射，确认实际加载的是本包 `/lab/bin/libotaivs.so.0.0.0`。

目标设备 iSulad 上的本包安装尚未执行；15 分钟历史长测试、24 小时历史及真实板卡均不列为本轮通过项。原有三个独立容器已由用户验收通过，不代表新增联调入口也已在现场通过。

三个新增 ELF 文件合计 2,385,688 字节（约 2.28 MiB）；运行包压缩后约 0.53 MiB，以交付文件实际大小为准。无需重新导入已有三个镜像，部署时只额外占用这些文件及受限日志、运行数据。

## 源码重建

源码覆盖层从本地已验收的 `/home/xiao_zhen/sonic-otn-complete` 复制，`source-manifest.json` 记录复制前 SHA256。`patch_stub.py` 仅增加虚拟 OTAI 的文件输入，保留原生调用接口。`build.sh` 复用先前 ARM64 成功构建容器中的编译器、头文件和库，通过 ARM64 用户态编译；不需要目标设备编译。`local-test.sh` 在开发机 Docker 中通过 QEMU 用户态运行 ARM64 原生二进制，不能替代现场 iSulad 验收。
