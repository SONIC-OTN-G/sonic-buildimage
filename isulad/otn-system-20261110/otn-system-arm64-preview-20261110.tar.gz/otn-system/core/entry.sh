#!/bin/sh
set -eu
exec python3 /lab/runtime.py "$@"
