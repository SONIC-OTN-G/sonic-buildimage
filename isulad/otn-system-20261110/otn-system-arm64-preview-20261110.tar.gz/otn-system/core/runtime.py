"""Container entrypoint: real daemons, bounded logs, no hardware access."""
import json,logging,logging.handlers,os,signal,socket,subprocess,sys,threading,time
from pathlib import Path

role=sys.argv[1]
state=Path('/lab-state');state.mkdir(exist_ok=True)
logger=logging.getLogger(role);logger.setLevel(logging.INFO)
handler=logging.handlers.RotatingFileHandler(str(state/(role+'.log')),maxBytes=2*1024*1024,backupCount=2)
handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'));logger.addHandler(handler)
children=[];stopping=False
def stop(*args):
 global stopping
 stopping=True
 for p in children:
  if p.poll() is None: p.terminate()
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
def syslog_reader():
 sock=socket.socket(socket.AF_UNIX,socket.SOCK_DGRAM)
 try: os.unlink('/dev/log')
 except FileNotFoundError: pass
 sock.bind('/dev/log')
 while True: logger.info(sock.recv(65536).decode(errors='replace'))
threading.Thread(target=syslog_reader,daemon=True).start()
def drain(p):
 for line in p.stdout: logger.info(line.rstrip())
def spawn(args):
 p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 children.append(p);threading.Thread(target=drain,args=(p,),daemon=True).start();return p
os.environ['LD_LIBRARY_PATH']='/lab/bin:/usr/lib:/usr/lib/aarch64-linux-gnu'
if role=='database':
 Path('/var/run/redis/sonic-db').mkdir(parents=True,exist_ok=True)
 names={'APPL_DB':(0,':'),'ASIC_DB':(1,':'),'COUNTERS_DB':(2,':'),'LOGLEVEL_DB':(3,':'),
        'CONFIG_DB':(4,'|'),'FLEX_COUNTER_DB':(5,':'),'STATE_DB':(6,'|'),'GB_COUNTERS_DB':(10,':'),
        'CHASSIS_APP_DB':(12,'|'),'CHASSIS_STATE_DB':(13,'|')}
 cfg={'INSTANCES':{'redis':{'hostname':'127.0.0.1','port':6379,'unix_socket_path':'/var/run/redis/redis.sock'}},
      'DATABASES':{n:{'id':i,'separator':sep,'instance':'redis'} for n,(i,sep) in names.items()},'VERSION':'1.0'}
 Path('/var/run/redis/sonic-db/database_config.json').write_text(json.dumps(cfg))
 args=['redis-server','--port','0','--unixsocket','/var/run/redis/redis.sock','--unixsocketperm','777',
       '--save','','--appendonly','no','--notify-keyspace-events','AKE','--databases','16',
       '--maxmemory','256mb','--maxmemory-policy','noeviction']
 if os.environ.get('ALLOW_EMULATION')=='1': args+=['--ignore-warnings','ARM64-COW-BUG']
 spawn(args)
else:
 import redis
 client=redis.Redis(unix_socket_path='/var/run/redis/redis.sock')
 for _ in range(600):
  try:
   if client.ping(): break
  except redis.RedisError: pass
  time.sleep(.1)
 else: raise RuntimeError('Redis not ready')
 if role=='syncd':
  Path('/tmp/linkup').touch()
  spawn(['/usr/bin/syncd'])
 elif role=='otss':
  spawn(['/lab/bin/orchagent','-i','0','-c','/lab/config/flexcounter.json'])
  spawn(['/lab/bin/configsyncd'])
 else: raise ValueError(role)
try:
 while not stopping:
  for p in children:
   if p.poll() is not None:
    raise RuntimeError('daemon exited: %s rc=%s'%(p.args,p.returncode))
  time.sleep(.2)
finally:
 stop()
 for p in children:
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait()
