#!/bin/sh
set -eu
# Run from any directory. Package MUST be under the engine's evidence directory.
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ENGINE=$(CDPATH= cd -- "$HERE/../.." && pwd)
BB="$ENGINE/bin/busybox"
test -f "$ENGINE/control.sh" || { echo 'Install under ENGINE/evidence/otn-linklab'; exit 1; }
test "$HERE" = "$ENGINE/evidence/otn-linklab" || { echo 'Unexpected install path'; exit 1; }
isula() { sh "$ENGINE/isula" "$@"; }
BASE=/evidence/otn-linklab
DB=sonic-database-standalone:arm64-20261022
OT=sonic-otss-standalone:arm64-20261023
SY=sonic-syncd-standalone:arm64-20261023
case "${1:-status}" in
 start)
  test -f "$HERE/bin/orchagent"; test -f "$HERE/bin/libotaivs.so.0"
  # Refuse to overwrite an existing run or collide with unrelated containers.
  for n in linklab-db linklab-otss linklab-syncd; do
   if isula inspect "$n" >/dev/null 2>&1; then echo "$n already exists: run stop first"; exit 1; fi
  done
  "$BB" mkdir -p "$HERE/state" "$HERE/runs"
  RUN="$("$BB" date +%Y%m%d-%H%M%S)-$$"
  "$BB" mkdir -p "$HERE/runs/$RUN/redis"
  printf '%s\n' "$RUN" > "$HERE/state/current-run"
  # Shared socket only: no host networking, devices or privileged mode.
  isula run -d --name linklab-db --label sonic.linklab=20261109 --network none \
   -v "$BASE:/lab:ro" -v "$BASE/state:/lab-state" -v "$BASE/runs/$RUN/redis:/var/run/redis" \
   --entrypoint /bin/sh "$DB" /lab/entry.sh database
  i=0
  until isula exec linklab-db redis-cli -s /var/run/redis/redis.sock PING 2>/dev/null | "$BB" grep -q PONG; do
   i=$((i+1)); test "$i" -lt 60 || { echo 'Redis timeout'; exit 1; }; "$BB" sleep 1
  done
  isula exec linklab-db python3 /lab/bootstrap.py
  isula run -d --name linklab-syncd --label sonic.linklab=20261109 --network none \
   -v "$BASE:/lab:ro" -v "$BASE/state:/lab-state" -v "$BASE/runs/$RUN/redis:/var/run/redis" \
   -v "$BASE/sim-data:/usr/include/vslib/otai_sim_data:ro" \
   --entrypoint /bin/sh "$SY" /lab/entry.sh syncd
  isula run -d --name linklab-otss --label sonic.linklab=20261109 --network none \
   -v "$BASE:/lab:ro" -v "$BASE/state:/lab-state" -v "$BASE/runs/$RUN/redis:/var/run/redis" \
   --entrypoint /bin/sh "$OT" /lab/entry.sh otss
  isula exec linklab-otss python3 /lab/check.py ready
  ;;
 stop)
  for n in linklab-otss linklab-syncd linklab-db; do
   if isula inspect "$n" >/dev/null 2>&1; then
    isula inspect "$n" | "$BB" grep -q '"sonic.linklab"[[:space:]]*:[[:space:]]*"20261109"' || { echo "Refuse unrelated container $n"; exit 1; }
    isula stop "$n"
    isula rm "$n"
   fi
  done
  ;;
 test|ready|config|pm|pm-history|alarm|show|save|get|set|inject-alarm|inject-pm)
  action=$1; shift
  test "$action" != test || action=all
  isula exec linklab-otss python3 /lab/check.py "$action" "$@"
  ;;
 status) isula ps -a ;;
 *) echo 'Usage: sh lab.sh start|stop|status|test|ready|config|pm|alarm|show|save|get|set|inject-alarm|inject-pm'; exit 2 ;;
esac
