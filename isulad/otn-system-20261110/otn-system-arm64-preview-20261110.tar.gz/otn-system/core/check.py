"""Acceptance through native SONiC daemons. Never writes result/PM/alarm tables."""
import argparse,fcntl,json,os,sys,time,uuid
from pathlib import Path
import redis
from swsscommon import swsscommon as s

SOCKET='/var/run/redis/redis.sock'
def db(n): return redis.Redis(unix_socket_path=SOCKET,db=n,decode_responses=True,socket_timeout=5)
cfg,app,counters,state,history=db(4),db(0),db(2),db(6),db(10)
ROOT=Path('/lab-state'); records=[]
def wait(fn,seconds=45,what='condition'):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  value=fn()
  if value:return value
  time.sleep(.1)
 raise TimeoutError(what)
def atomic(name,value):
 p=ROOT/name;tmp=p.with_suffix('.tmp')
 with tmp.open('w') as f: json.dump(value,f);f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
def event(**kw): atomic('events.json',dict(sequence=time.time_ns(),**kw))
def subscription(channel):
 p=state.pubsub();p.subscribe(channel)
 wait(lambda:(m:=p.get_message()) and m['type']=='subscribe',what='subscription acknowledgement')
 return p
def readback(key,field,channel='AMPLIFIER_NOTIFICATION'):
 reply='OT_READBACK-'+str(uuid.uuid4());p=subscription(reply)
 try:
  app.publish(channel,json.dumps(['get',key,field,'','__reply-channel',reply]))
  m=wait(lambda:(m:=p.get_message()) and m['type']=='message' and m,what='OTAI GET reply')
  value=json.loads(m['data'])
  if value[0]!='SUCCESS':raise RuntimeError(value)
  return dict(zip(value[2::2],value[3::2]))[field]
 finally:p.close()
def apply(key,field,value,expect_success=True):
 op=str(uuid.uuid4());channel=field+'-'+op;p=subscription(channel)
 try:
  cfg.hset('AMPLIFIER|'+key,mapping={field:str(value),'operation-id':op})
  result=wait(lambda:state.hgetall('OT_OPERATION_RESULT|'+channel),what='durable configuration response')
  if (int(result['status'])==0)!=expect_success: raise AssertionError(result)
  # The durable result and live notification must both correlate to this request.
  message=wait(lambda:(m:=p.get_message()) and m['type']=='message' and m,what='live configuration reply')
  assert int(json.loads(message['data'])[0])==int(result['status'])
  return dict(operation=op,**result)
 finally:p.close()
def ready():
 expected=json.loads(Path('/lab/config/config_db.json').read_text())
 count=sum(len(rows) for t,rows in expected.items() if t not in ('LINECARD','DEVICE_METADATA'))
 def initialized():
  keys=list(state.scan_iter('OT_OBJECT_STATUS|*'))
  return len(keys)==count and all(state.hget(k,'phase')=='APPLIED' for k in keys)
 wait(initialized,180,'all configured objects APPLIED')
 assert readback('AMPLIFIER-1-1-1','target-gain') is not None
 return {'objects':count,'backend':'virtual OTAI; no hardware'}
def config_test():
 key='AMPLIFIER-1-1-1';other='AMPLIFIER-1-1-2';field='target-gain'
 before=readback(key,field);peer=readback(other,field);reply=None
 try:
  reply=apply(key,field,'13')
  assert abs(float(readback(key,field))-13)<1e-6
  assert readback(other,field)==peer,'object isolation violated'
 finally:
  apply(key,field,before)
  assert abs(float(readback(key,field))-float(before))<1e-6,'restore failed'
 mode=readback(key,'amp-mode')
 try:
  rejection=apply(key,'amp-mode','LINKLAB_INVALID_ENUM',False)
  assert readback(key,'amp-mode')==mode
 finally:apply(key,'amp-mode',mode)
 return {'set_reply':reply,'before':before,'set_readback':'13','restored':True,'invalid_enum_rejected':rejection}
def pm_test():
 path=ROOT/'stats.json';old=json.loads(path.read_text()) if path.exists() else {}
 def samples(target):
  matches=[]
  for k in counters.scan_iter('AMPLIFIER:AMPLIFIER-1-1-1*'):
   if 'actualgain' not in k.lower().replace('-','').replace('_',''):continue
   row=counters.hgetall(k)
   if 'instant' in row and abs(float(row['instant'])-target)<1e-6:matches.append((k,row))
  return matches
 try:
  atomic('stats.json',{'OTAI_OA_STAT_ACTUAL_GAIN':12.25})
  first=wait(lambda:samples(12.25),what='PM first sample from syncd collector')
  atomic('stats.json',{'OTAI_OA_STAT_ACTUAL_GAIN':17.75})
  second=wait(lambda:samples(17.75),what='PM changed sample from syncd collector')
  return {'first':first,'second':second,'source':'virtual OTAI getStats -> native syncd collector -> COUNTERS_DB'}
 finally:atomic('stats.json',old)
def alarm_test():
 pattern='CURALARM|*HIGH_TEMPERATURE_ALARM*'
 event(alarm_active=False)
 wait(lambda:not list(state.scan_iter(pattern)),what='alarm initially clear')
 before=set(history.scan_iter('HISALARM:*'))
 try:
  event(alarm_active=True)
  active=wait(lambda:list(state.scan_iter(pattern)),what='native active alarm')
  row=state.hgetall(active[0]);assert 'LINKLAB' in row.get('text','')
  event(alarm_active=True);time.sleep(1)
  assert len(list(state.scan_iter(pattern)))==1,'duplicate active alarm'
  event(alarm_active=False)
  wait(lambda:not list(state.scan_iter(pattern)),what='native alarm clearance')
  cleared=wait(lambda:set(history.scan_iter('HISALARM:*'))-before,what='native historical alarm')
  historical={k:history.hgetall(k) for k in cleared}
  assert all('time-cleared' in v for v in historical.values())
  return {'active':row,'history':historical,'duplicate_suppressed':True}
 finally:event(alarm_active=False)
def pm_history_test():
 def matching():
  return {k for k in history.scan_iter('AMPLIFIER:AMPLIFIER-1-1-1*')
          if 'actualgain' in k.lower().replace('-','').replace('_','') and ':15_pm_history_' in k}
 before=matching()
 print('Waiting up to 960 seconds for the native 15-minute boundary; no clock changes.',flush=True)
 keys=wait(lambda:matching()-before,960,'native 15-minute PM history')
 rows={k:history.hgetall(k) for k in keys}
 for row in rows.values():
  assert all(field in row for field in ('starttime','interval','validity','min','max','avg','instant'))
 return {'history':rows,'note':'first partial window may legitimately be incomplete'}
def save():
 tables=json.loads(Path('/lab/config/config_db.json').read_text());saved={}
 for table,rows in tables.items():
  saved[table]={key:{f:v for f,v in cfg.hgetall(table+'|'+key).items() if f!='operation-id'} for key in rows}
 atomic('startup.json',saved);return {'saved':'state/startup.json'}
def show():
 return {'objects':{k:state.hgetall(k) for k in state.scan_iter('OT_OBJECT_STATUS|*')},
         'alarms':{k:state.hgetall(k) for k in state.scan_iter('CURALARM|*')},
         'pm_keys':list(counters.scan_iter('AMPLIFIER:*'))}
def manual(action,values):
 if action in ('get','set'):
  expected=2 if action=='get' else 3
  if len(values)!=expected:raise ValueError('get OBJECT FIELD / set OBJECT FIELD VALUE')
  key,field=values[:2]
  if key not in ('AMPLIFIER-1-1-1','AMPLIFIER-1-1-2'):raise ValueError('unknown lab amplifier')
  if field not in ('target-gain','amp-mode','enabled'):raise ValueError('field outside lab allowlist')
  if action=='get':return {'value':readback(key,field)}
  if field=='target-gain':
   number=float(values[2])
   if not 0<=number<=30:raise ValueError('lab gain range is 0..30')
  result=apply(key,field,values[2]);result['readback']=readback(key,field);return result
 if action=='inject-alarm':
  if values not in (['on'],['off']):raise ValueError('inject-alarm on|off')
  event(alarm_active=values==['on']);return {'submitted':'virtual OTAI alarm event','active':values==['on']}
 if action=='inject-pm':
  if len(values)!=1:raise ValueError('inject-pm NUMBER')
  value=float(values[0])
  if not 0<=value<=30:raise ValueError('lab range is 0..30')
  atomic('stats.json',{'OTAI_OA_STAT_ACTUAL_GAIN':value});return {'submitted':'virtual OTAI getStats input','value':value}
 raise ValueError(action)
def run(name,fn):
 started=time.time()
 try:result=fn();record={'case':name,'status':'PASS','result':result}
 except Exception as e:record={'case':name,'status':'FAIL','error':repr(e)};raise
 finally:
  record['seconds']=round(time.time()-started,3);records.append(record)
  print(json.dumps(record,ensure_ascii=False),flush=True)
  atomic('latest-results.json',{'scope':'native ARM64 SONiC communication with virtual OTAI','records':records})
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('action',choices=['ready','config','pm','pm-history','alarm','all','show','save','get','set','inject-alarm','inject-pm']);parser.add_argument('values',nargs='*');args=parser.parse_args()
 with (ROOT/'test.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  actions={'ready':ready,'config':config_test,'pm':pm_test,'pm-history':pm_history_test,'alarm':alarm_test,'save':save,'show':show}
  for action in ('get','set','inject-alarm','inject-pm'):actions[action]=lambda action=action:manual(action,args.values)
  for name in (['ready','config','pm','alarm'] if args.action=='all' else [args.action]):run(name,actions[name])
