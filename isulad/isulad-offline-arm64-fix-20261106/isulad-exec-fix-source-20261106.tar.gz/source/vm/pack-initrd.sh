#!/bin/bash
set -euo pipefail
cd /src/vm/initramfs510
find . -print0 | cpio --null -o --format=newc 2>/src/vm/initrd-build.log | gzip -1 > /src/vm/initrd510.gz
