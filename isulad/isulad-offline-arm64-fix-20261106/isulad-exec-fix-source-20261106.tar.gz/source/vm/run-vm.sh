#!/bin/bash
set -euo pipefail
exec qemu-system-aarch64 -machine virt -cpu cortex-a72 -accel tcg -smp 4 -m 4096 -nographic -no-reboot -kernel /src/vm-kernel510/boot/vmlinuz-5.10.0-32-arm64 -initrd /src/vm/initrd510.gz -append 'console=ttyAMA0 rdinit=/init panic=-1' -drive file=/src/vm/device.ext4,format=raw,if=none,id=d0 -device virtio-blk-pci,drive=d0 -net none
