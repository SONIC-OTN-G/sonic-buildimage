#!/bin/sh
set -eu
trap 'echo $? > /ofs1/vm-status' EXIT
cd /ofs1/isulad-offline-arm64
BB=$PWD/bin/busybox
uname -a
cat /proc/self/mountinfo | head -n 5 || true
cat /proc/cgroups
# Missing-overlay preflight must fail clearly, before a daemon is started.
if ! grep -qw overlay /proc/filesystems; then
 if sh control.sh start; then echo FAIL_missing_overlay_accepted; exit 1; fi
 echo PASS_missing_overlay_rejected
 modprobe overlay
fi
sh control.sh start
sh control.sh status
# Confirm host custom hierarchy was not replaced and devices was not added
# to HOST namespace by the private preparation script.
grep ' /ofs1/vendor-cgroups/cpu ' /proc/mounts
grep cgroup /proc/mounts
sh test.sh smoke
if ! sh isula images | grep -q sonic-syncd-standalone; then sh test.sh load-sonic; fi
sh test.sh database
sh test.sh ot
sh control.sh collect
"$BB" gzip -t diagnostics.tar.gz
echo PASS_diagnostics_archive
sh control.sh stop
echo PASS_ALL_ARM64_FULL_SYSTEM_TESTS
