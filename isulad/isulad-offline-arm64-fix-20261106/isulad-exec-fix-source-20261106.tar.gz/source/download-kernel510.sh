#!/bin/bash
set -euo pipefail
echo 'deb http://deb.debian.org/debian bullseye main' > /etc/apt/sources.list.d/bullseye.list
apt-get update > /src/kernel510-download.log 2>&1
cd /src
apt-cache show linux-image-arm64:arm64 | grep -E 'Version|Depends' >>/src/kernel510-download.log
K=$(apt-cache show linux-image-arm64:arm64 | sed -n 's/^Depends: \(linux-image-5\.10[^ ,]*\).*/\1/p' | head -1)
[ -n "$K" ]
apt-get download "$K:arm64" >>/src/kernel510-download.log 2>&1
mkdir -p /src/vm-kernel510
dpkg-deb -x /src/${K}_*.deb /src/vm-kernel510
