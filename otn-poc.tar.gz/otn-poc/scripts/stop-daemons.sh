#!/bin/sh
pkill -f 'bin/syncd' 2>/dev/null
pkill -f 'bin/orchagent' 2>/dev/null
pkill -f 'bin/linecardmgrd' 2>/dev/null
pkill -f 'bin/configsyncd' 2>/dev/null
sleep 1
echo "=== daemons stopped (redis untouched)"
