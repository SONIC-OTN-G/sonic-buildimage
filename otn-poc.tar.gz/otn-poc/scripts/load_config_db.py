#!/usr/bin/env python3
"""Load a config_db.json into CONFIG_DB (replaces sonic-cfggen -j ... --write-to-db)."""
import json, sys
from swsscommon.swsscommon import ConfigDBConnector

def iter_entries(cfg):
    for k, v in cfg.items():
        if '|' in k and isinstance(v, dict):          # flat "TABLE|KEY" shape
            t, _, key = k.partition('|')
            yield t, key, v or {}
        elif isinstance(v, dict):                     # standard nested shape
            for key, fields in v.items():
                yield k, key, fields or {}

def main(path):
    with open(path) as f:
        cfg = json.load(f)
    db = ConfigDBConnector()
    db.db_connect('CONFIG_DB')
    n = 0
    for table, key, fields in iter_entries(cfg):
        db.set_entry(table, key, {f: str(v) for f, v in fields.items()})
        n += 1
    print('loaded %d entries from %s' % (n, path))

if __name__ == '__main__':
    main(sys.argv[1])
