#!/bin/sh
BASE=$(cd $(dirname $0)/.. && pwd)
export LD_LIBRARY_PATH=$BASE/lib
export OTAI_SIM_DATA_PATH=$BASE/otai_sim_data
cd $BASE

mkdir -p /usr/share/swss
cp $BASE/swss/*.lua /usr/share/swss

printf 'OTAI_LINECARD_LOCATION=1\nOTAI_VS_LINECARD_TYPE=OTAI_VS_LINECARD_TYPE_OTN\n' > /tmp/otai_test.profile
./bin/syncd -p /tmp/otai_test.profile &
sleep 5

./bin/orchagent -b 8192 &
sleep 2
./bin/linecardmgrd &
./bin/configsyncd &
echo "=== daemons started"
