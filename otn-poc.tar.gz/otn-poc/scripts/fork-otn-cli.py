#!/usr/bin/env python3
"""将随附 otn CLI 源码改造为设备（裸进程）执行：

1. slot.py::create_linecard_config_file —— systemctl/docker/j2/sonic-cfggen 编排
   改为调用载荷本地脚本（stop/load/start + redis-cli power-enable + touch linkup）
2. config_utils.py::config_save —— sonic-cfggen 导出改为 dump_config_db.py
3. 补充 os/sys 导入
幂等：锚点消失即跳过。
"""
import sys

NEW_CREATE = '''def create_linecard_config_file(slot_id, cfg_type, board_mode=None):
    asic_id = slot_id - 1
    base = os.environ.get('OTN_POC_BASE', '.')

    # 停 OTSS/syncd（redis 保持运行，等价 VM 侧只停 otss@/syncd-ot@ 服务）
    run_command(f'sh {base}/scripts/stop-daemons.sh')

    # 使用预渲染 linecard 配置（打包时以 SLOT_ID/ASIC_ID 渲染自 config_db.json.j2）
    if board_mode is None:
        cfg_file = f'{base}/linecards/{cfg_type.upper()}/config_db.json'
    else:
        cfg_file = f'{base}/linecards/{cfg_type.upper()}/{board_mode.upper()}/config_db.json'

    # 装载 linecard 配置到 CONFIG_DB（随附 python 取代 sonic-cfggen）
    run_command(f'{sys.executable} {base}/scripts/load_config_db.py {cfg_file}')

    # 起 OTSS/syncd
    run_command(f'sh {base}/scripts/start-daemons.sh')

    asic_type = get_asic_type()
    if asic_type == 'ot-vs':
        time.sleep(5)
        print(f"plugin the virtual linecard {slot_id} and power enabled...")
        run_command(f'{base}/bin/redis-cli -s /var/run/redis/redis.sock -n 6 hset '
                    f'"LINECARD|LINECARD-1-{slot_id}" "power-admin-state" "POWER_ENABLED" '
                    f'"empty" "false" "linecard-type" "{cfg_type.upper()}"')

        time.sleep(5)
        print(f"virtual linecard otai library communication link status is up...")
        run_command('touch /tmp/linkup')
'''

NEW_SAVE = '''def config_save(slot_id = 0):
    SLOTS_DEFAULT_CONFIG_DB_FILE = '/etc/sonic/config_db{}.json'
    HOST_DEFAULT_CONFIG_DB_FILE = '/etc/sonic/config_db.json'
    try:
        if slot_id in get_linecard_slot_range():
            db_id = slot_id - 1
            out_file = SLOTS_DEFAULT_CONFIG_DB_FILE.format(db_id)
        else:
            out_file = HOST_DEFAULT_CONFIG_DB_FILE
        base = os.environ.get('OTN_POC_BASE', '.')
        run_command(f'{sys.executable} {base}/scripts/dump_config_db.py > {out_file}')
    except Exception as e:
        click.echo(e)
'''

def main(root):
    slot = root + '/otn/slot/slot.py'
    cfgu = root + '/otn/utils/config_utils.py'

    text = open(slot).read()
    if 'systemctl' in text:
        i = text.index('def create_linecard_config_file')
        j = text.index('def config_linecard_type_none')
        text = text[:i] + NEW_CREATE + '\n' + text[j:]
        text = text.replace('import click\nimport time\n',
                            'import click\nimport os\nimport sys\nimport time\n', 1)
        open(slot, 'w').write(text)
        print('patched: otn/slot/slot.py')
    else:
        print('skip: otn/slot/slot.py (already patched)')

    text = open(cfgu).read()
    if 'SONIC_CFGGEN_PATH' in text:
        i = text.index('def config_save')
        text = text[:i] + NEW_SAVE
        text = text.replace('import click\nimport uuid\n',
                            'import click\nimport os\nimport sys\nimport uuid\n', 1)
        open(cfgu, 'w').write(text)
        print('patched: otn/utils/config_utils.py')
    else:
        print('skip: otn/utils/config_utils.py (already patched)')

if __name__ == '__main__':
    main(sys.argv[1])
