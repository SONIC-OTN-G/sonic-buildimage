# bin/config、bin/show source this file；也可手动 source（在 payload 根目录，或预置 BASE）
# BASE 解析：调用方传入 > CWD 探测（sourced 场景下 $0 是 shell 名，不可靠）
if [ -z "$BASE" ]; then
    if [ -d py-pkgs/usr/lib/python3/dist-packages ] && [ -x python3/usr/bin/python3.9 ]; then
        BASE=$(pwd)
    else
        echo "WARN: BASE 未设置且当前目录不是 payload 根目录，请先 cd 到 payload 根目录" >&2
        return 1 2>/dev/null || exit 1
    fi
fi
export OTN_POC_BASE=$BASE
export LD_LIBRARY_PATH=$BASE/lib:$BASE/python3/lib/aarch64-linux-gnu:$BASE/python3/usr/lib/aarch64-linux-gnu
export PYTHONHOME=$BASE/python3/usr
export PYTHONPATH=$BASE/py-pkgs/usr/lib/python3/dist-packages:$BASE/py-lib/usr/lib/python3/dist-packages

# CLI 静态依赖供给（幂等；get_asic_type / get_chassis_capability 依赖）
mkdir -p /etc/sonic 2>/dev/null
if [ ! -f /etc/sonic/sonic_version.yml ]; then
    if [ -f $BASE/conf/sonic_version.yml ]; then
        cp $BASE/conf/sonic_version.yml /etc/sonic/ 2>/dev/null \
            && echo "OK: 已部署 /etc/sonic/sonic_version.yml" \
            || echo "WARN: /etc/sonic 不可写，get_asic_type 将返回 None（ot-vs 分支不会走）"
    else
        echo "WARN: 源文件 $BASE/conf/sonic_version.yml 不存在（payload 不完整?）"
    fi
fi
mkdir -p /usr/share/sonic/device/x86_64-ot_kvm_x86_64_4_asic-r0 2>/dev/null
if [ ! -f /usr/share/sonic/device/x86_64-ot_kvm_x86_64_4_asic-r0/chassis_cli_capability.json ]; then
    if [ -f $BASE/conf/chassis_cli_capability.json ]; then
        cp $BASE/conf/chassis_cli_capability.json /usr/share/sonic/device/x86_64-ot_kvm_x86_64_4_asic-r0/ 2>/dev/null \
            && echo "OK: 已部署 chassis_cli_capability.json" \
            || echo "WARN: /usr/share 不可写，chassis_cli_capability 读取将失败"
    else
        echo "WARN: 源文件 $BASE/conf/chassis_cli_capability.json 不存在（payload 不完整?）"
    fi
fi
