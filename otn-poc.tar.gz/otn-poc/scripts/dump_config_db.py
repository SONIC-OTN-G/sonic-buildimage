#!/usr/bin/env python3
"""Dump CONFIG_DB as config_db.json to stdout (replaces sonic-cfggen -d --print-data)."""
import json
from swsscommon.swsscommon import ConfigDBConnector

db = ConfigDBConnector()
db.db_connect('CONFIG_DB')
out = {}
for key in db.keys('CONFIG_DB', '*'):
    table, _, k = key.partition('|')
    if not k:
        continue
    entry = db.get_entry(table, k) or {}
    out.setdefault(table, {})[k] = {f: str(v) for f, v in entry.items()}
print(json.dumps(out, indent=4))
